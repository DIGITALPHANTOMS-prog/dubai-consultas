const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;

// Servir arquivos estáticos
app.use(express.static(__dirname));

// Rota principal
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'sistema-consulta.html'));
});

// Rota para carregar dados do servidor.txt
app.get('/api/dados', (req, res) => {
    try {
        const dados = fs.readFileSync('servidor.txt', 'utf8');
        const linhas = dados.trim().split('\n');
        const cabecalho = linhas[0].split(',');
        
        const registros = linhas.slice(1).map(linha => {
            const valores = linha.split(',');
            const registro = {};
            cabecalho.forEach((coluna, index) => {
                registro[coluna.trim()] = valores[index] ? valores[index].trim() : '';
            });
            return registro;
        });
        
        res.json(registros);
    } catch (error) {
        console.error('Erro ao ler arquivo:', error);
        res.status(500).json({ error: 'Erro ao carregar dados' });
    }
});

// Rota para buscar dados adicionais na API externa
app.get('/api/dados-extras/:cpf', async (req, res) => {
    try {
        const { cpf } = req.params;
        const url = `https://api.bronxservices.net/consulta/dHJhdmVsZXI6QENhc3RpZWwxMA==/srs22/cpf/${cpf}`;
        
        console.log(`🔍 Buscando dados para CPF: ${cpf}`);
        console.log(`🌐 URL da API: ${url}`);
        
        const response = await fetch(url);
        console.log(`📡 Status da resposta: ${response.status}`);
        
        if (response.ok) {
            const dados = await response.json();
            console.log(`✅ Dados recebidos com sucesso`);
            res.json(dados);
        } else if (response.status === 502) {
            console.log(`❌ API externa indisponível (502 Bad Gateway)`);
            res.status(503).json({ 
                error: 'API externa temporariamente indisponível',
                message: 'A API externa está fora do ar no momento. Tente novamente mais tarde.',
                status: 502
            });
        } else {
            console.log(`❌ Erro na API externa: ${response.status}`);
            res.status(response.status).json({ 
                error: 'Erro na API externa',
                message: `A API externa retornou erro ${response.status}`,
                status: response.status
            });
        }
    } catch (error) {
        console.error('❌ Erro ao buscar dados externos:', error);
        res.status(500).json({ 
            error: 'Erro de conexão',
            message: 'Não foi possível conectar com a API externa. Verifique sua conexão com a internet.',
            details: error.message
        });
    }
});

// Novas rotas para consultas da API Bronx
app.get('/api/consulta-cpf/:cpf', async (req, res) => {
    try {
        const cpf = req.params.cpf;
        const url = `https://api.bronxservices.net/consulta/dHJhdmVsZXI6QENhc3RpZWwxMA==/srs22/cpf/${cpf}`;
        
        const response = await fetch(url);
        
        // Verificar se a resposta é JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            console.error('API retornou HTML em vez de JSON:', await response.text());
            return res.status(500).json({ 
                message: 'API externa retornou formato inválido. Tente novamente mais tarde.' 
            });
        }
        
        const dados = await response.json();
        
        if (response.ok) {
            res.json(dados);
        } else {
            res.status(response.status).json({ message: 'Erro na consulta da API externa' });
        }
    } catch (error) {
        console.error('Erro na consulta CPF:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
});

app.get('/api/consulta-telefone/:telefone', async (req, res) => {
    try {
        const telefone = req.params.telefone;
        const url = `https://api.bronxservices.net/consulta/dHJhdmVsZXI6QENhc3RpZWwxMA==/srs22/telefone/${telefone}`;
        
        const response = await fetch(url);
        
        // Verificar se a resposta é JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            console.error('API retornou HTML em vez de JSON:', await response.text());
            return res.status(500).json({ 
                message: 'API externa retornou formato inválido. Tente novamente mais tarde.' 
            });
        }
        
        const dados = await response.json();
        
        if (response.ok) {
            res.json(dados);
        } else {
            res.status(response.status).json({ message: 'Erro na consulta da API externa' });
        }
    } catch (error) {
        console.error('Erro na consulta telefone:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
});

app.get('/api/consulta-nome/:nome', async (req, res) => {
    try {
        const nome = req.params.nome;
        const url = `https://api.bronxservices.net/consulta/dHJhdmVsZXI6QENhc3RpZWwxMA==/serasa/nome/${encodeURIComponent(nome)}`;
        
        const response = await fetch(url);
        
        // Verificar se a resposta é JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            console.error('API retornou HTML em vez de JSON:', await response.text());
            return res.status(500).json({ 
                message: 'API externa retornou formato inválido. Tente novamente mais tarde.' 
            });
        }
        
        const dados = await response.json();
        
        if (response.ok) {
            res.json(dados);
        } else {
            res.status(response.status).json({ message: 'Erro na consulta da API externa' });
        }
    } catch (error) {
        console.error('Erro na consulta nome:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
});

app.get('/api/consulta-endereco/:cpf', async (req, res) => {
    try {
        const cpf = req.params.cpf;
        const url = `https://api.bronxservices.net/consulta/dHJhdmVsZXI6QENhc3RpZWwxMA==/serasa/enderecos/${cpf}`;
        
        const response = await fetch(url);
        
        // Verificar se a resposta é JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            console.error('API retornou HTML em vez de JSON:', await response.text());
            return res.status(500).json({ 
                message: 'API externa retornou formato inválido. Tente novamente mais tarde.' 
            });
        }
        
        const dados = await response.json();
        
        if (response.ok) {
            res.json(dados);
        } else {
            res.status(response.status).json({ message: 'Erro na consulta da API externa' });
        }
    } catch (error) {
        console.error('Erro na consulta endereço:', error);
        res.status(500).json({ message: 'Erro interno do servidor' });
    }
});

// Função para obter IP local
function getLocalIP() {
    const { networkInterfaces } = require('os');
    const nets = networkInterfaces();
    
    for (const name of Object.keys(nets)) {
        for (const net of nets[name]) {
            if (net.family === 'IPv4' && !net.internal) {
                return net.address;
            }
        }
    }
    return 'localhost';
}

// Iniciar servidor
app.listen(PORT, () => {
    const localIP = getLocalIP();
    console.log(`\n╔══════════════════════════════════════════════════════════════╗`);
    console.log(`║                    🏆 DUBAI CONSULTAS 🏆                    ║`);
    console.log(`╠══════════════════════════════════════════════════════════════╣`);
    console.log(`║                                                              ║`);
    console.log(`║  🔗 Local:     http://localhost:${PORT}                        ║`);
    console.log(`║  🌐 Rede:      http://${localIP}:${PORT}                        ║`);
    console.log(`║                                                              ║`);
    console.log(`║  👤 Login:     admin                                          ║`);
    console.log(`║  🔐 Senha:     admin123                                       ║`);
    console.log(`║                                                              ║`);
    console.log(`║  💡 Para parar: Ctrl+C                                       ║`);
    console.log(`╚══════════════════════════════════════════════════════════════╝\n`);
});

// Tratamento de erros
app.use((err, req, res, next) => {
    console.error('Erro:', err);
    res.status(500).send('Erro interno do servidor');
});
